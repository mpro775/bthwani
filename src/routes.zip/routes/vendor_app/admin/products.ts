import express from "express";
import {
  getPendingProducts,
  updateProductStatus,
} from "../../../controllers/admin/productController";
const router = express.Router();

// يمكن لاحقًا إضافة authAdmin middleware
/**
 * @route GET /pending
 * @tags Admin
 * @summary Retrieve pending
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/pending", getPendingProducts);
/**
 * @route PATCH /:id/status
 * @tags Admin
 * @summary Update status by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id/status", updateProductStatus);

export default router;