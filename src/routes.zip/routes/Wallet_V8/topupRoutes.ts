// routes/topupRoutes.ts
import express from "express";
import { getLogsHandler, topupHandler } from "../../controllers/Wallet_V8/topupController";
import { payBillHandler } from "../../controllers/Wallet_V8/payBillController";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { TopupLog } from "../../models/Wallet_V8/TopupLog";

const router = express.Router();
/**
 * @route POST /topup
 * @tags WalletV8
 * @summary Create topup
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/topup", topupHandler);
/**
 * @route POST /pay-bill
 * @tags WalletV8
 * @summary Create pay bill
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/pay-bill", payBillHandler);
/**
 * @route GET /logs
 * @tags WalletV8
 * @summary Retrieve logs
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/logs", getLogsHandler);
/**
 * @route GET /my-logs
 * @tags WalletV8
 * @summary Retrieve my logs
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/my-logs", verifyFirebase, async (req, res) => {
  try {
    const logs = await TopupLog.find({ userId: req.user.id }).sort({
      createdAt: -1,
    });
    res.json(logs);
  } catch (err) {
    res.status(500).json({ message: "فشل في جلب العمليات" });
  }
});
export default router;