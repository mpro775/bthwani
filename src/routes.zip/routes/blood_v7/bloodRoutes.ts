import express from "express";
import {
  createBloodRequest,
  getAllBloodDonors,
  markDonationComplete,
} from "../../controllers/blood_v7/bloodRequestController";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { BloodMessage } from "../../models/blood_V7/BloodMessageSchema";
import { User } from "../../models/user";

const router = express.Router();

// إنشاء طلب دم جديد
/**
 * @route POST /request
 * @tags BloodV7
 * @summary Create request
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/request", verifyFirebase, createBloodRequest);
/**
 * @route POST /complete
 * @tags BloodV7
 * @summary Create complete
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/complete", verifyFirebase, markDonationComplete);

/**
 * @route POST /blood/messages
 * @tags BloodV7
 * @summary Create blood messages
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/blood/messages", verifyFirebase, async (req, res) => {
  const { requestId, text } = req.body;
  const senderId = req.user.id;

  if (!text || !requestId) {
    res.status(400).json({ message: "بيانات ناقصة" });
    return;
  }

  const message = await BloodMessage.create({ requestId, text, senderId });
  res.json(message);
});

/**
 * @route GET /blood/messages/:requestId
 * @tags BloodV7
 * @summary Retrieve blood messages by requestId
 * @param {requestId} requestId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/blood/messages/:requestId", verifyFirebase, async (req, res) => {
  const messages = await BloodMessage.find({
    requestId: req.params.requestId,
  }).sort({ sentAt: 1 });
  res.json(messages);
});

/**
 * @route GET /donors
 * @tags BloodV7
 * @summary Retrieve donors
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/donors", verifyFirebase, getAllBloodDonors);

export default router;