import express from "express";
import * as controller from "../../controllers/delivry_Marketplace_V1/DeliveryStoreController";
import { verifyAdmin } from "../../middleware/verifyAdmin"; // ✅ إضافة الحماية
import { verifyFirebase } from "../../middleware/verifyFirebase";

const router = express.Router();

// 🛡️ حماية كافة المسارات الخاصة بإدارة المتاجر
router.post(
  "/",
  verifyFirebase,
  verifyAdmin,

  controller.create
);

router.put(
  "/:id",
  verifyFirebase,

  verifyAdmin,
  controller.update
);
/**
 * @route GET /
 * @tags DelivryMarketplaceV1
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", controller.getAll);
/**
 * @route GET /:id
 * @tags DelivryMarketplaceV1
 * @summary Retrieve by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id", controller.getById);
/**
 * @route PUT /:id
 * @tags DelivryMarketplaceV1
 * @summary Update by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.put("/:id", verifyFirebase, verifyAdmin, controller.update);
/**
 * @route DELETE /:id
 * @tags DelivryMarketplaceV1
 * @summary Delete by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/:id", verifyFirebase, verifyAdmin, controller.remove);

export default router;