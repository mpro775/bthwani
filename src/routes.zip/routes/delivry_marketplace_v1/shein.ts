import express, { NextFunction, Request, Response } from "express";

import mongoose from "mongoose";
import { SheinCart } from "../../models/delivry_Marketplace_V1/sheincart";
import { User } from "../../models/user";
import { SheinOrder } from "../../models/delivry_Marketplace_V1/SheinOrder";

const router = express.Router();

/**
 * @route POST /checkout
 * @tags DelivryMarketplaceV1
 * @summary Create checkout
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/checkout", async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const userId = req.user?.id;
    if (!userId) {
      res.status(401).json({ message: "غير مصرح" });
      return;
    }

    const user = await User.findById(userId).session(session);
    if (!user) {
      res.status(404).json({ message: "المستخدم غير موجود" });
      return;
    }

    const cart = await SheinCart.findOne({ userId }).session(session);
    if (!cart || cart.items.length === 0){
            res.status(400).json({ message: "السلة فارغة" });

          return;

    }
    const total = cart.items.reduce(
      (sum, i) => sum + i.price * (i.quantity || 1),
      0
    );

    if ((user.wallet?.balance || 0) < total) {
      res.status(402).json({ message: "رصيد المحفظة غير كافٍ" });
      return;
    }

    user.wallet.balance -= total;
    await user.save({ session });

    const sheinOrder = new SheinOrder({
      userId,
      items: cart.items,
      totalPrice: total,
      status: "paid",
      paidAt: new Date(),
    });

    await sheinOrder.save({ session });
    await SheinCart.deleteOne({ _id: cart._id }).session(session);

    await session.commitTransaction();
    res
      .status(201)
      .json({ message: "تم تنفيذ الطلب", orderId: sheinOrder._id });
  } catch (err: any) {
    await session.abortTransaction();
    res.status(500).json({ message: "خطأ داخلي", error: err.message });
  } finally {
    session.endSession();
  }
});

export default router;