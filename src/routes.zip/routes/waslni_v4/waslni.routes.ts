import express from "express";
import {
  createBooking,
  acceptBooking,
  startRide,
  completeRide,
  uploadProof,
  cancelBooking,
  getAllBookings,
  submitReview,
  sendSOS,
  confirmOTP,
  getMyBookings,
  getWaslniStats,
} from "../../controllers/waslni_v5/waslniController";
import multer from "multer";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { verifyAdmin } from "../../middleware/verifyAdmin";

const router = express.Router();
const upload = multer({ dest: "uploads/" }); // مؤقتًا، يمكن استبداله بتكامل سحابي لاحقًا

// 🟢 المستخدم
/**
 * @route POST /request
 * @tags WaslniV4
 * @summary Create request
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/request", verifyFirebase, createBooking);
/**
 * @route PATCH /:id/cancel
 * @tags WaslniV4
 * @summary Update cancel by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id/cancel", verifyFirebase, cancelBooking);
/**
 * @route GET /stats
 * @tags WaslniV4
 * @summary Retrieve stats
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/stats", verifyFirebase, verifyAdmin, getWaslniStats);

// 🟠 السائق
/**
 * @route PATCH /:id/accept
 * @tags WaslniV4
 * @summary Update accept by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id/accept",  acceptBooking);
/**
 * @route PATCH /:id/start
 * @tags WaslniV4
 * @summary Update start by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id/start",  startRide);
/**
 * @route PATCH /:id/complete
 * @tags WaslniV4
 * @summary Update complete by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id/complete",  completeRide);
/**
 * @route POST /:id/proof
 * @tags WaslniV4
 * @summary Create proof by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/:id/proof",  upload.single("image"), uploadProof);

// 🔵 الإدمن
/**
 * @route GET /
 * @tags WaslniV4
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", verifyAdmin, getAllBookings);


/**
 * @route POST /:id/review
 * @tags WaslniV4
 * @summary Create review by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/:id/review", verifyFirebase, submitReview);
/**
 * @route POST /:id/sos
 * @tags WaslniV4
 * @summary Create sos by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/:id/sos", verifyFirebase, sendSOS);
/**
 * @route POST /:id/confirm-otp
 * @tags WaslniV4
 * @summary Create confirm otp by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/:id/confirm-otp", verifyFirebase, confirmOTP);
/**
 * @route GET /my-bookings
 * @tags WaslniV4
 * @summary Retrieve my bookings
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/my-bookings", verifyFirebase, getMyBookings);

export default router;