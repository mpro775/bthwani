import express from "express";
import { placeBid } from "../../controllers/Haraj_V2/auctionController";
import { verifyFirebase } from "../../middleware/verifyFirebase";

const router = express.Router();

/**
 * @route POST /:id/bid
 * @tags HarajV2
 * @summary Create bid by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/:id/bid", verifyFirebase, placeBid);

export default router;