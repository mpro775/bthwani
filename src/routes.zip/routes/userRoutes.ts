import { Router } from "express";
import { verifyFirebase } from "../middleware/verifyFirebase";
import {
  registerOrUpdateUser,
  getCurrentUser,
  updateProfile,
  updateSecurity,
  setPinCode,
  verifyPinCode,
  getUserStats,
  deactivateAccount,
  getAddresses,
} from "../controllers/user/userController";
import {
  addAddress,
  deleteAddress,
  setDefaultAddress,
  updateAddress,
} from "../controllers/user/addressController";
import {
  getTransactions,
  getTransferHistory,
  getWallet,
  transferFunds,
} from "../controllers/Wallet_V8/walletController";
import {
  followUser,
  unfollowUser,
  getFollowers,
  getFollowing,
  getActivityLog,
} from "../controllers/user/socialController";
import {
  updateBloodSettings,
  updateFreelancerProfile,
} from "../controllers/user/extraUserController";
import {
  getNotifications,
  markAllNotificationsRead,
} from "../controllers/user/notificationsController";

const router = Router();

/**
 * @swagger
 * tags:
 *   name: User
 *   description: عمليات المستخدم
 */

/**
 * @swagger
 * /me:
 *   get:
 *     summary: استرجاع معلومات المستخدم الحالي
 *     tags: [User]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: تفاصيل المستخدم
 */
/**
 * @route GET /me
 * @tags Routes
 * @summary Retrieve me
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/me", verifyFirebase, getCurrentUser);

/**
 * @swagger
 * /init:
 *   post:
 *     summary: تسجيل أو تحديث بيانات المستخدم
 *     tags: [User]
 */
/**
 * @route POST /init
 * @tags Routes
 * @summary Create init
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/init", verifyFirebase, registerOrUpdateUser);

/**
 * @swagger
 * /profile:
 *   patch:
 *     summary: تعديل بيانات الحساب
 *     tags: [User]
 */
/**
 * @route PATCH /profile
 * @tags Routes
 * @summary Update profile
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/profile", verifyFirebase, updateProfile);

/**
 * @swagger
 * /security:
 *   patch:
 *     summary: تحديث إعدادات الأمان
 *     tags: [User]
 */
/**
 * @route PATCH /security
 * @tags Routes
 * @summary Update security
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/security", verifyFirebase, updateSecurity);

/**
 * @swagger
 * /security/set-pin:
 *   patch:
 *     summary: تعيين رمز PIN
 *     tags: [User]
 */
/**
 * @route PATCH /security/set-pin
 * @tags Routes
 * @summary Update security set pin
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/security/set-pin", verifyFirebase, setPinCode);

/**
 * @swagger
 * /security/verify-pin:
 *   patch:
 *     summary: التحقق من رمز PIN
 *     tags: [User]
 */
/**
 * @route PATCH /security/verify-pin
 * @tags Routes
 * @summary Update security verify pin
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/security/verify-pin", verifyFirebase, verifyPinCode);

/**
 * @swagger
 * /me/stats:
 *   get:
 *     summary: إحصائيات المستخدم
 *     tags: [User]
 */
/**
 * @route GET /me/stats
 * @tags Routes
 * @summary Retrieve me stats
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/me/stats", verifyFirebase, getUserStats);

/**
 * @swagger
 * /me/deactivate:
 *   delete:
 *     summary: حذف الحساب
 *     tags: [User]
 */
/**
 * @route DELETE /me/deactivate
 * @tags Routes
 * @summary Delete me deactivate
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/me/deactivate", verifyFirebase, deactivateAccount);

/**
 * @swagger
 * /address:
 *   get:
 *     summary: الحصول على العناوين
 *     tags: [User]
 */
/**
 * @route GET /address
 * @tags Routes
 * @summary Retrieve address
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/address", verifyFirebase, getAddresses);

/**
 * @swagger
 * /address:
 *   post:
 *     summary: إضافة عنوان
 *     tags: [User]
 */
/**
 * @route POST /address
 * @tags Routes
 * @summary Create address
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/address", verifyFirebase, addAddress);

/**
 * @swagger
 * /address/{id}:
 *   patch:
 *     summary: تحديث عنوان
 *     tags: [User]
 */
/**
 * @route PATCH /address/:id
 * @tags Routes
 * @summary Update address by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/address/:id", verifyFirebase, updateAddress);

/**
 * @swagger
 * /address/{id}:
 *   delete:
 *     summary: حذف عنوان
 *     tags: [User]
 */
/**
 * @route DELETE /address/:id
 * @tags Routes
 * @summary Delete address by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/address/:id", verifyFirebase, deleteAddress);

/**
 * @swagger
 * /default-address:
 *   patch:
 *     summary: تعيين عنوان افتراضي
 *     tags: [User]
 */
/**
 * @route PATCH /default-address
 * @tags Routes
 * @summary Update default address
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/default-address", verifyFirebase, setDefaultAddress);

/**
 * @swagger
 * /wallet:
 *   get:
 *     summary: عرض المحفظة
 *     tags: [Wallet]
 */
/**
 * @route GET /wallet
 * @tags Routes
 * @summary Retrieve wallet
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/wallet", verifyFirebase, getWallet);

/**
 * @swagger
 * /transactions:
 *   get:
 *     summary: سجل المعاملات
 *     tags: [Wallet]
 */
/**
 * @route GET /transactions
 * @tags Routes
 * @summary Retrieve transactions
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/transactions", verifyFirebase, getTransactions);

/**
 * @swagger
 * /wallet/transfer:
 *   post:
 *     summary: تحويل أموال
 *     tags: [Wallet]
 */
/**
 * @route POST /wallet/transfer
 * @tags Routes
 * @summary Create wallet transfer
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/wallet/transfer", verifyFirebase, transferFunds);

/**
 * @swagger
 * /wallet/transfer-history:
 *   get:
 *     summary: سجل التحويلات
 *     tags: [Wallet]
 */
/**
 * @route GET /wallet/transfer-history
 * @tags Routes
 * @summary Retrieve wallet transfer history
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/wallet/transfer-history", verifyFirebase, getTransferHistory);

/**
 * @swagger
 * /blood-settings:
 *   patch:
 *     summary: تحديث إعدادات التبرع بالدم
 *     tags: [User]
 */
/**
 * @route PATCH /blood-settings
 * @tags Routes
 * @summary Update blood settings
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/blood-settings", verifyFirebase, updateBloodSettings);

/**
 * @swagger
 * /freelancer-profile:
 *   patch:
 *     summary: تحديث الملف الحر
 *     tags: [User]
 */
/**
 * @route PATCH /freelancer-profile
 * @tags Routes
 * @summary Update freelancer profile
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/freelancer-profile", verifyFirebase, updateFreelancerProfile);

/**
 * @swagger
 * /follow/{targetId}:
 *   post:
 *     summary: متابعة مستخدم
 *     tags: [Social]
 */
/**
 * @route POST /follow/:targetId
 * @tags Routes
 * @summary Create follow by targetId
 * @param {targetId} targetId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/follow/:targetId", verifyFirebase, followUser);

/**
 * @swagger
 * /unfollow/{targetId}:
 *   delete:
 *     summary: إلغاء المتابعة
 *     tags: [Social]
 */
/**
 * @route DELETE /unfollow/:targetId
 * @tags Routes
 * @summary Delete unfollow by targetId
 * @param {targetId} targetId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/unfollow/:targetId", verifyFirebase, unfollowUser);

/**
 * @swagger
 * /{id}/followers:
 *   get:
 *     summary: عرض المتابعين
 *     tags: [Social]
 */
/**
 * @route GET /:id/followers
 * @tags Routes
 * @summary Retrieve followers by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id/followers", getFollowers);

/**
 * @swagger
 * /{id}/following:
 *   get:
 *     summary: عرض المتابَعين
 *     tags: [Social]
 */
/**
 * @route GET /:id/following
 * @tags Routes
 * @summary Retrieve following by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id/following", getFollowing);

/**
 * @swagger
 * /activity:
 *   get:
 *     summary: سجل النشاطات
 *     tags: [User]
 */
/**
 * @route GET /activity
 * @tags Routes
 * @summary Retrieve activity
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/activity", verifyFirebase, getActivityLog);

/**
 * @swagger
 * /notifications:
 *   get:
 *     summary: عرض التنبيهات
 *     tags: [Notifications]
 */
/**
 * @route GET /notifications
 * @tags Routes
 * @summary Retrieve notifications
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/notifications", verifyFirebase, getNotifications);

/**
 * @swagger
 * /notifications/mark-read:
 *   patch:
 *     summary: تعليم كل الإشعارات كمقروءة
 *     tags: [Notifications]
 */
router.patch(
  "/notifications/mark-read",
  verifyFirebase,
  markAllNotificationsRead
);

export default router;