// routes/charity.routes.ts
import express from "express";
import { postDonation, getMyDonations, getUnassignedDonations, assignToOrganization } from "../../controllers/Charity_V10/charity.controller";
import { verifyFirebase } from "../../middleware/verifyFirebase";

const router = express.Router();

/**
 * @route POST /charity/post
 * @tags CharityV10
 * @summary Create charity post
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/charity/post", verifyFirebase, postDonation);
/**
 * @route GET /charity/mine
 * @tags CharityV10
 * @summary Retrieve charity mine
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/charity/mine", verifyFirebase, getMyDonations);
/**
 * @route GET /charity/unassigned
 * @tags CharityV10
 * @summary Retrieve charity unassigned
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/charity/unassigned", verifyFirebase, getUnassignedDonations);
/**
 * @route PATCH /charity/assign
 * @tags CharityV10
 * @summary Update charity assign
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/charity/assign", verifyFirebase, assignToOrganization);

export default router;