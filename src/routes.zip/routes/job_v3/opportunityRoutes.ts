import express from "express";
import {
  createOpportunity,
  getOpportunities,
  getOpportunityById,
  updateOpportunity,
  deleteOpportunity,
} from "../../controllers/job_V3/opportunityController";
import { verifyFirebase } from "../../middleware/verifyFirebase";

const router = express.Router();

/**
 * @route POST /
 * @tags JobV3
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", verifyFirebase, createOpportunity);
/**
 * @route GET /
 * @tags JobV3
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", verifyFirebase, getOpportunities);
/**
 * @route GET /:id
 * @tags JobV3
 * @summary Retrieve by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id", verifyFirebase, getOpportunityById);
/**
 * @route PATCH /:id
 * @tags JobV3
 * @summary Update by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id", verifyFirebase, updateOpportunity);
/**
 * @route DELETE /:id
 * @tags JobV3
 * @summary Delete by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/:id", verifyFirebase, deleteOpportunity);

export default router;