// routes/miscRoutes.ts
import express from "express";
import { getFAQs } from "../../controllers/job_V3/miscController";

const router = express.Router();
/**
 * @route GET /faqs
 * @tags JobV3
 * @summary Retrieve faqs
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/faqs", getFAQs);
export default router;