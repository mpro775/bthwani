// routes/freelancerRoutes.ts
import express from "express";
import { getAvailability } from "../../controllers/job_V3/freelancerController";

const router = express.Router();
/**
 * @route GET /:id/availability
 * @tags JobV3
 * @summary Retrieve availability by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id/availability", getAvailability);
export default router;