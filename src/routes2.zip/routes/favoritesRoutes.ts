import express from "express";
import { verifyFirebase } from "../middleware/verifyFirebase";
import {
  addFavorite,
  getFavoritesByUser,
  removeFavorite,
} from "../controllers/user/favoritesController";

const router = express.Router();

router.use(verifyFirebase); // ✅ مصادقة Firebase أو JWT

/**
 * @route POST /
 * @tags Routes
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", addFavorite); // إضافة للمفضلة
/**
 * @route DELETE /
 * @tags Routes
 * @summary Delete
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/", removeFavorite); // حذف من المفضلة
/**
 * @route GET /
 * @tags Routes
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", getFavoritesByUser); // جلب المفضلة حسب المستخدم

export default router;