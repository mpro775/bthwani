// 3. wallet.routes.ts
import express from "express";
import { getWallet, chargeWalletViaKuraimi, verifyCustomer, reverseTransaction, getWalletAnalytics } from "../../controllers/Wallet_V8/wallet.controller";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { getAllWithdrawals, processWithdrawal, requestWithdrawal } from "../../controllers/Wallet_V8/withdrawal.controller";
import { verifyAdmin } from "../../middleware/verifyAdmin";

const router = express.Router();

/**
 * @route GET /wallet
 * @tags WalletV8
 * @summary Retrieve wallet
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/wallet", verifyFirebase, getWallet);
/**
 * @route POST /wallet/charge/kuraimi
 * @tags WalletV8
 * @summary Create wallet charge kuraimi
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/wallet/charge/kuraimi", verifyFirebase, chargeWalletViaKuraimi);
/**
 * @route POST /wallet/verify-customer
 * @tags WalletV8
 * @summary Create wallet verify customer
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/wallet/verify-customer", verifyCustomer);
/**
 * @route POST /wallet/reverse/:refNo
 * @tags WalletV8
 * @summary Create wallet reverse by refNo
 * @param {refNo} refNo.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/wallet/reverse/:refNo", verifyFirebase, reverseTransaction);
/**
 * @route POST /wallet/withdraw-request
 * @tags WalletV8
 * @summary Create wallet withdraw request
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/wallet/withdraw-request", verifyFirebase, requestWithdrawal);
/**
 * @route GET /admin/withdrawals
 * @tags WalletV8
 * @summary Retrieve admin withdrawals
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/admin/withdrawals", verifyFirebase, getAllWithdrawals);
/**
 * @route POST /admin/withdrawals/:id/process
 * @tags WalletV8
 * @summary Create admin withdrawals process by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/admin/withdrawals/:id/process", verifyAdmin, processWithdrawal);
/**
 * @route GET /wallet/analytics
 * @tags WalletV8
 * @summary Retrieve wallet analytics
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/wallet/analytics", verifyFirebase, getWalletAnalytics);

export default router;