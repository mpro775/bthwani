import express from "express";
import {
  createCoupon,
  validateCoupon,
  markCouponAsUsed,
  redeemPoints,
} from "../../controllers/Wallet_V8/coupon.controller";
import { verifyAdmin } from "../../middleware/verifyAdmin";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { Coupon } from "../../models/Wallet_V8/coupon.model";

const router = express.Router();

/**
 * @route POST /coupons
 * @tags WalletV8
 * @summary Create coupons
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/coupons", verifyAdmin, createCoupon);
/**
 * @route POST /coupons/validate
 * @tags WalletV8
 * @summary Create coupons validate
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/coupons/validate", verifyFirebase, validateCoupon);
/**
 * @route POST /coupons/use
 * @tags WalletV8
 * @summary Create coupons use
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/coupons/use", verifyFirebase, markCouponAsUsed);
/**
 * @route GET /coupons/user
 * @tags WalletV8
 * @summary Retrieve coupons user
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/coupons/user", verifyFirebase, async (req, res) => {
  const coupons = await Coupon.find({
    $or: [{ assignedTo: req.user.id }, { assignedTo: null }],
    expiryDate: { $gte: new Date() },
    usedCount: { $lt: "$usageLimit" },
  });
  res.json(coupons);
});
/**
 * @route POST /coupons/redeem
 * @tags WalletV8
 * @summary Create coupons redeem
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/coupons/redeem", verifyFirebase, redeemPoints);

export default router;