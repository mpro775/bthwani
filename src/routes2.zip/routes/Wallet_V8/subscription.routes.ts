import express from "express";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { createSubscription, getMySubscription } from "../../controllers/Wallet_V8/subscription.controller";

const router = express.Router();

/**
 * @route GET /my
 * @tags WalletV8
 * @summary Retrieve my
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/my", verifyFirebase, getMySubscription);
/**
 * @route POST /
 * @tags WalletV8
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", verifyFirebase, createSubscription);

export default router;