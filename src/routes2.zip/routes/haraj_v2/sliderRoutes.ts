import { Router } from "express";
import {
  getSliders,
  createSlider,
} from "../../controllers/Haraj_V2/bannerControllers";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { verifyAdmin } from "../../middleware/verifyAdmin";
import multer from "multer";
const upload = multer({ dest: "temp/" });

const router = Router();

/**
 * @route GET /
 * @tags HarajV2
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", getSliders);
/**
 * @route POST /
 * @tags HarajV2
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", verifyFirebase, verifyAdmin, createSlider);

export default router;