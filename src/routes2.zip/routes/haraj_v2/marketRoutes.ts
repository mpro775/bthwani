import { Router } from "express";
import {
  createProduct,
  getAllProducts,
  getProductById,
  updateProduct,
  deleteProduct,
  getFilteredProducts,
  getActiveOffers,
  getSimilarProducts,
  toggleLikeProduct,
  addComment,
  adminUpdateStatus,
  reportProduct,
  requestBarter,
  getMyProducts,
  getProductBids,
  getProductAnalytics,
  getNearbyProducts,
} from "../../controllers/Haraj_V2/productController";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { verifyAdmin } from "../../middleware/verifyAdmin";
import multer from "multer";


const router = Router();

/**
 * @route POST /products
 * @tags HarajV2
 * @summary Create products
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/products", verifyFirebase, createProduct);
/**
 * @route GET /admin/products
 * @tags HarajV2
 * @summary Retrieve admin products
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/admin/products", verifyFirebase, verifyAdmin, getAllProducts); // هذا يرجع كل المنتجات
/**
 * @route GET /products/:id
 * @tags HarajV2
 * @summary Retrieve products by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/products/:id", getProductById);
/**
 * @route GET /products/:id/bids
 * @tags HarajV2
 * @summary Retrieve products bids by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/products/:id/bids", getProductBids);
/**
 * @route GET /products/:id/analytics
 * @tags HarajV2
 * @summary Retrieve products analytics by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/products/:id/analytics", getProductAnalytics);
/**
 * @route GET /products/nearby
 * @tags HarajV2
 * @summary Retrieve products nearby
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/products/nearby", getNearbyProducts);

/**
 * @route PATCH /products/:id
 * @tags HarajV2
 * @summary Update products by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/products/:id", verifyFirebase, updateProduct);
/**
 * @route DELETE /products/:id
 * @tags HarajV2
 * @summary Delete products by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/products/:id", verifyFirebase, deleteProduct);
/**
 * @route PATCH /products/:id/like
 * @tags HarajV2
 * @summary Update products like by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/products/:id/like", verifyFirebase, toggleLikeProduct);
/**
 * @route POST /products/:id/comment
 * @tags HarajV2
 * @summary Create products comment by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/products/:id/comment", verifyFirebase, addComment);
router.patch(
  "/products/:id/status",
  verifyFirebase,
  verifyAdmin,
  adminUpdateStatus
);
/**
 * @route GET /products/my-products
 * @tags HarajV2
 * @summary Retrieve products my products
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/products/my-products", verifyFirebase, getMyProducts);

/**
 * @route POST /products/:id/report
 * @tags HarajV2
 * @summary Create products report by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/products/:id/report", verifyFirebase, reportProduct);

/**
 * @route POST /products/:id/barter
 * @tags HarajV2
 * @summary Create products barter by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/products/:id/barter", verifyFirebase, requestBarter);

/**
 * @route GET /products
 * @tags HarajV2
 * @summary Retrieve products
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/products", getFilteredProducts); // هذا يدعم الفلاتر: category, condition, hasOffer
/**
 * @route GET /products/active-offers
 * @tags HarajV2
 * @summary Retrieve products active offers
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/products/active-offers", getActiveOffers);
/**
 * @route GET /products/:id/similar
 * @tags HarajV2
 * @summary Retrieve products similar by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/products/:id/similar", getSimilarProducts);

export default router;