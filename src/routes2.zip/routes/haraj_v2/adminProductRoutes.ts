import { Router } from "express";
import {
  adminGetAllProducts,
  adminUpdateProduct,
} from "../../controllers/Haraj_V2/adminProductController";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { verifyAdmin } from "../../middleware/verifyAdmin";

const router = Router();

/**
 * @route GET /
 * @tags HarajV2
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", verifyFirebase, verifyAdmin, adminGetAllProducts);
/**
 * @route PATCH /:id
 * @tags HarajV2
 * @summary Update by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id", verifyFirebase, verifyAdmin, adminUpdateProduct);

export default router;