import { NextFunction, Response, Router, Request } from "express";
import {
  createCategory,
  deleteCategory,
  getNestedCategories,
  updateCategory,
} from "../../controllers/Haraj_V2/categoryController";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { verifyAdmin } from "../../middleware/verifyAdmin";
import { getCategoriesWithCounts } from "../../controllers/Haraj_V2/categoryController";

import multer from "multer";

const router = Router();
const upload = multer({ dest: "temp/" });

/**
 * @route POST /
 * @tags HarajV2
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", verifyFirebase, verifyAdmin, createCategory);
/**
 * @route GET /
 * @tags HarajV2
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", getCategoriesWithCounts);

// فئات - Admin فقط

/**
 * @route PATCH /:id
 * @tags HarajV2
 * @summary Update by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id", verifyFirebase, verifyAdmin, updateCategory);
/**
 * @route DELETE /:id
 * @tags HarajV2
 * @summary Delete by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/:id", verifyFirebase, verifyAdmin, deleteCategory);
/**
 * @route GET /nested
 * @tags HarajV2
 * @summary Retrieve nested
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/nested", getNestedCategories);

export default router;