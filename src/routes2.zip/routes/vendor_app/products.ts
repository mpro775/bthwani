import express from "express";
import { createProduct } from "../../controllers/vendor_app/productController";
import { authVendor } from "../../middleware/authVendor";
const router = express.Router();

router.use(authVendor);
/**
 * @route POST /
 * @tags VendorApp
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", createProduct);

export default router;