import express from "express";
import { addVendor } from "../../../controllers/admin/vendorController";
const router = express.Router();

// يمكن لاحقًا إضافة authAdmin middleware
/**
 * @route POST /
 * @tags Admin
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", addVendor);

export default router;