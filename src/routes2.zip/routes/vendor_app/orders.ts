// routes/vendor/orders.ts
import express from "express";
import {
  getVendorOrders,
  updateOrderStatus,
} from "../../controllers/vendor_app/orderController";
import { authVendor } from "../../middleware/authVendor";
const router = express.Router();

router.use(authVendor);
/**
 * @route GET /
 * @tags VendorApp
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", getVendorOrders);
/**
 * @route PATCH /:id/status
 * @tags VendorApp
 * @summary Update status by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id/status", updateOrderStatus);

export default router;