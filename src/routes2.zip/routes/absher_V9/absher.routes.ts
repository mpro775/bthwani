import express from "express";
import {
  submitRequest,
  getMyRequests,
  assignRequestToProvider,
  providerRespond,
  withdrawPercentage,
} from "../../controllers/absher_v9/absher.controller";
import { verifyFirebase } from "../../middleware/verifyFirebase";

const router = express.Router();

/**
 * @route POST /absher/request
 * @tags AbsherV9
 * @summary Create absher request
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/absher/request", verifyFirebase, submitRequest);
/**
 * @route GET /absher/my-requests
 * @tags AbsherV9
 * @summary Retrieve absher my requests
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/absher/my-requests", verifyFirebase, getMyRequests);
/**
 * @route PATCH /absher/admin/assign
 * @tags AbsherV9
 * @summary Update absher admin assign
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/absher/admin/assign", verifyFirebase, assignRequestToProvider);
/**
 * @route PATCH /absher/provider/respond
 * @tags AbsherV9
 * @summary Update absher provider respond
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/absher/provider/respond", verifyFirebase, providerRespond);
/**
 * @route POST /absher/provider/withdraw
 * @tags AbsherV9
 * @summary Create absher provider withdraw
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/absher/provider/withdraw", verifyFirebase, withdrawPercentage);

export default router;