import express from "express";
import {
  sendMessage,
  getMessages,
} from "../../controllers/lost_v6/messageController";

const router = express.Router();

/**
 * @route POST /
 * @tags LostV6
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", sendMessage); // إرسال رسالة
/**
 * @route GET /:itemId
 * @tags LostV6
 * @summary Retrieve by itemId
 * @param {itemId} itemId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:itemId", getMessages); // جلب الرسائل لبلاغ معيّن

export default router;