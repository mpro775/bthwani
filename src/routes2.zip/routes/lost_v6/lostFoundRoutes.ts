import express from "express";
import {
  createPost,
  getPosts,
  getPostDetails,
  updatePostStatus,
} from "../../controllers/lost_v6/lostFoundController";

const router = express.Router();

/**
 * @route POST /
 * @tags LostV6
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", createPost);
/**
 * @route GET /
 * @tags LostV6
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", getPosts);
/**
 * @route GET /:id
 * @tags LostV6
 * @summary Retrieve by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id", getPostDetails);
/**
 * @route PATCH /:id/status
 * @tags LostV6
 * @summary Update status by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id/status", updatePostStatus);

export default router;