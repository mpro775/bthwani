import express from "express";
import { verifyFirebase } from "../middleware/verifyFirebase";
import { uploadAvatar } from "../controllers/user/userAvatarController";

const router = express.Router();

/**
 * @route PATCH /avatar
 * @tags Routes
 * @summary Update avatar
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/avatar", verifyFirebase,  uploadAvatar);

export default router;