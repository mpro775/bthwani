import express from "express";
import { loginDriver, changePassword, updateLocation, updateAvailability, getMyProfile, updateMyProfile, addOtherLocation, deleteOtherLocation, getMyOrders, completeOrder, addReviewForUser } from "../../controllers/driver_app/driver.controller";
import { authenticate } from "../../middleware/auth.middleware";

const router = express.Router();

/**
 * @route POST /login
 * @tags DriverApp
 * @summary Create login
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/login", loginDriver);
/**
 * @route PATCH /change-password
 * @tags DriverApp
 * @summary Update change password
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/change-password", authenticate, changePassword);
/**
 * @route PATCH /location
 * @tags DriverApp
 * @summary Update location
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/location", authenticate, updateLocation);
/**
 * @route GET /me
 * @tags DriverApp
 * @summary Retrieve me
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/me", authenticate, getMyProfile);
/**
 * @route PATCH /me
 * @tags DriverApp
 * @summary Update me
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/me", authenticate, updateMyProfile);
/**
 * @route POST /locations
 * @tags DriverApp
 * @summary Create locations
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/locations", authenticate, addOtherLocation);
/**
 * @route DELETE /locations/:index
 * @tags DriverApp
 * @summary Delete locations by index
 * @param {index} index.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/locations/:index", authenticate, deleteOtherLocation);
/**
 * @route GET /orders
 * @tags DriverApp
 * @summary Retrieve orders
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/orders", authenticate, getMyOrders);
/**
 * @route POST /complete/:orderId
 * @tags DriverApp
 * @summary Create complete by orderId
 * @param {orderId} orderId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/complete/:orderId", authenticate, completeOrder);
/**
 * @route POST /review
 * @tags DriverApp
 * @summary Create review
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/review", authenticate, addReviewForUser);

/**
 * @route PATCH /availability
 * @tags DriverApp
 * @summary Update availability
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/availability", authenticate, updateAvailability);
export default router;