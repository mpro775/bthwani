import express from "express";
import { authenticate } from "../../middleware/auth.middleware";
import {
  requestWithdrawal,
  getMyWithdrawals,
} from "../../controllers/driver_app/driver.withdrawal.controller";

const router = express.Router();

/**
 * @route POST /
 * @tags DriverApp
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", authenticate, requestWithdrawal);
/**
 * @route GET /
 * @tags DriverApp
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", authenticate, getMyWithdrawals);

export default router;