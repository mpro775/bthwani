// src/routes/deliveryCart.routes.ts
import express from "express";
import * as controller from "../../controllers/delivry_Marketplace_V1/DeliveryCartController";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { optionalAuth } from "../../middleware/optionalAuth";
const router = express.Router();

router.use(optionalAuth);

// GET /cart/:cartId   أو  /cart/user/:userId
/**
 * @route GET /user/:userId
 * @tags DelivryMarketplaceV1
 * @summary Retrieve user by userId
 * @param {userId} userId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/user/:userId", controller.getCart);
/**
 * @route GET /:cartId
 * @tags DelivryMarketplaceV1
 * @summary Retrieve by cartId
 * @param {cartId} cartId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:cartId", controller.getCart);

// POST /cart/add
/**
 * @route POST /add
 * @tags DelivryMarketplaceV1
 * @summary Create add
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/add", controller.addOrUpdateCart);

// DELETE ...
/**
 * @route DELETE /user/:userId
 * @tags DelivryMarketplaceV1
 * @summary Delete user by userId
 * @param {userId} userId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/user/:userId", controller.clearCart);
/**
 * @route DELETE /:cartId
 * @tags DelivryMarketplaceV1
 * @summary Delete by cartId
 * @param {cartId} cartId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/:cartId", controller.clearCart);

// في deliveryCart.routes.ts
/**
 * @route DELETE /:cartId/items/:productId
 * @tags DelivryMarketplaceV1
 * @summary Delete items by cartId and productId
 * @param {cartId} cartId.path.required - TODO: describe
 * @param {productId} productId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/:cartId/items/:productId", controller.removeItem);
/**
 * @route DELETE /user/:userId/items/:productId
 * @tags DelivryMarketplaceV1
 * @summary Delete user items by userId and productId
 * @param {userId} userId.path.required - TODO: describe
 * @param {productId} productId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/user/:userId/items/:productId", controller.removeItem);

// باقي المسارات
/**
 * @route GET /
 * @tags DelivryMarketplaceV1
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", controller.getAllCarts);
/**
 * @route GET /abandoned
 * @tags DelivryMarketplaceV1
 * @summary Retrieve abandoned
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/abandoned", controller.getAbandonedCarts);
/**
 * @route POST /merge
 * @tags DelivryMarketplaceV1
 * @summary Create merge
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/merge", verifyFirebase, controller.mergeCart);

export default router;