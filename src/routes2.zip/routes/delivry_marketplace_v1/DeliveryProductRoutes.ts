import express from "express";
import * as controller from "../../controllers/delivry_Marketplace_V1/DeliveryProductController";
import { verifyAdmin } from "../../middleware/verifyAdmin"; // ✅ حماية الأدمن
import { verifyFirebase } from "../../middleware/verifyFirebase";
import DeliveryProduct from "../../models/delivry_Marketplace_V1/DeliveryProduct";

const router = express.Router();

// 🛡️ حماية كافة المسارات الخاصة بالمنتجات
/**
 * @route POST /
 * @tags DelivryMarketplaceV1
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", verifyFirebase, verifyAdmin, controller.create);
/**
 * @route GET /
 * @tags DelivryMarketplaceV1
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", controller.getAll);
/**
 * @route GET /:id
 * @tags DelivryMarketplaceV1
 * @summary Retrieve by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id", controller.getById);
/**
 * @route PUT /:id
 * @tags DelivryMarketplaceV1
 * @summary Update by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.put("/:id", verifyFirebase, verifyAdmin, controller.update);
/**
 * @route DELETE /:id
 * @tags DelivryMarketplaceV1
 * @summary Delete by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/:id", verifyFirebase, verifyAdmin, controller.remove);

/**
 * @route GET /daily-offers
 * @tags DelivryMarketplaceV1
 * @summary Retrieve daily offers
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/daily-offers", async (req, res) => {
  try {
    const offers = await DeliveryProduct.find({ isDailyOffer: true }).limit(10);
    res.json(offers);
  } catch (err) {
    res.status(500).json({ message: "خطأ في جلب العروض اليومية" });
  }
});

/**
 * @route GET /nearby/new
 * @tags DelivryMarketplaceV1
 * @summary Retrieve nearby new
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/nearby/new", async (req, res) => {
  const { lat, lng } = req.query;

  if (!lat || !lng) {
    res.status(400).json({ message: "إحداثيات الموقع مطلوبة" });
    return;
  }

  const parsedLat = parseFloat(lat as string);
  const parsedLng = parseFloat(lng as string);

  if (isNaN(parsedLat) || isNaN(parsedLng)) {
    res.status(400).json({ message: "إحداثيات غير صالحة" });
    return;
  }

  try {
    const recentProducts = await DeliveryProduct.find({
      location: {
        $near: {
          $geometry: {
            type: "Point",
            coordinates: [parsedLng, parsedLat], // ⚠️ ترتيب: [lng, lat]
          },
          $maxDistance: 5000,
        },
      },
    })
      .sort({ createdAt: -1 })
      .limit(10);

    res.json(recentProducts);
  } catch (err) {
    res.status(500).json({ message: "خطأ في جلب المنتجات الجديدة" });
  }
});

export default router;