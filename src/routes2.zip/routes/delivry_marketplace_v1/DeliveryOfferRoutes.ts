import express from "express";
import * as controller from "../../controllers/delivry_Marketplace_V1/DeliveryOfferController";
import { verifyAdmin } from "../../middleware/verifyAdmin";

const router = express.Router();

/**
 * @route POST /
 * @tags DelivryMarketplaceV1
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", verifyAdmin, controller.create);
/**
 * @route GET /
 * @tags DelivryMarketplaceV1
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", controller.getAll);
/**
 * @route GET /:id
 * @tags DelivryMarketplaceV1
 * @summary Retrieve by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id", verifyAdmin, controller.getById);
/**
 * @route PUT /:id
 * @tags DelivryMarketplaceV1
 * @summary Update by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.put("/:id", verifyAdmin, controller.update);
/**
 * @route DELETE /:id
 * @tags DelivryMarketplaceV1
 * @summary Delete by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/:id", verifyAdmin, controller.remove);

export default router;