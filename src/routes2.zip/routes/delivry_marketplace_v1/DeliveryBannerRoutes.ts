import express from "express";
import * as controller from "../../controllers/delivry_Marketplace_V1/DeliveryBannerController";
import { verifyAdmin } from "../../middleware/verifyAdmin";
import { verifyFirebase } from "../../middleware/verifyFirebase";

const router = express.Router();

/**
 * @route POST /
 * @tags DelivryMarketplaceV1
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", verifyFirebase, verifyAdmin, controller.create);
/**
 * @route GET /
 * @tags DelivryMarketplaceV1
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", controller.getAll);
/**
 * @route GET /:id
 * @tags DelivryMarketplaceV1
 * @summary Retrieve by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id", verifyFirebase, verifyAdmin, controller.getById);
/**
 * @route PUT /:id
 * @tags DelivryMarketplaceV1
 * @summary Update by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.put("/:id", verifyFirebase, verifyAdmin, controller.update);
/**
 * @route DELETE /:id
 * @tags DelivryMarketplaceV1
 * @summary Delete by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/:id", verifyFirebase, verifyAdmin, controller.remove);

export default router;