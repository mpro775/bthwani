import express, { NextFunction, Request, Response } from "express";
import * as controller from "../../controllers/delivry_Marketplace_V1/DeliveryOrderController";
import { verifyAdmin } from "../../middleware/verifyAdmin";
import { verifyAdminOrDriver } from "../../middleware/verifyAdminOrDriver";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { body, validationResult } from "express-validator";
import Order from "../../models/delivry_Marketplace_V1/Order";
import { requireRole } from "../../middleware/auth";

const createOrderValidators = [
  body("addressId").isMongoId(),
  body("city").optional(), // للتوافق العكسي إن أردت
  body("latitude").optional(), // لن تحتاجها بعد
  body("longitude").optional(), // لن تحتاجها بعد
];

const router = express.Router();
router.use(verifyFirebase);
router.post(
  "/",
  createOrderValidators,
  async (req: Request, res: Response, next: NextFunction) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(400).json({ errors: errors.array() });
      return;
    }
    next();
  },
  controller.createOrder
);

/**
 * @route GET /vendor/orders
 * @tags DelivryMarketplaceV1
 * @summary Retrieve vendor orders
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/vendor/orders", requireRole(["vendor"]), async (req, res) => {
  const vendorId = req.user.id;
  const orders = await Order.find({ "subOrders.storeId": vendorId });
  res.json(orders);
});

/**
 * @route GET /user/:userId
 * @tags DelivryMarketplaceV1
 * @summary Retrieve user by userId
 * @param {userId} userId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/user/:userId", controller.getUserOrders);
/**
 * @route GET /:id
 * @tags DelivryMarketplaceV1
 * @summary Retrieve by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id", controller.getOrderById);
/**
 * @route GET /
 * @tags DelivryMarketplaceV1
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", verifyAdmin, controller.getAllOrders); // للأدمن مع فلترة
/**
 * @route PUT /:id
 * @tags DelivryMarketplaceV1
 * @summary Update by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.put("/:id", verifyAdminOrDriver, controller.updateOrderStatus);

export default router;