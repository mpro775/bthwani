import { Router } from "express";
import { Request, Response } from "express";

import {
  getAllUsers,
  getUserById,
  updateUserAdmin,
  updateUserRole,
} from "../../controllers/admin/adminUserController";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import { verifyAdmin } from "../../middleware/verifyAdmin";
import { User } from "../../models/user";
import { getUserStats } from "../../controllers/user/userController";
import { verifyCapability } from "../../middleware/verifyCapability";
import Order from "../../models/delivry_Marketplace_V1/Order";
import { requireRole } from "../../middleware/auth";

const router = Router();

/**
 * @route GET /users
 * @tags Admin
 * @summary Retrieve users
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/users", verifyFirebase, getAllUsers);
/**
 * @route GET /users/:id
 * @tags Admin
 * @summary Retrieve users by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/users/:id", verifyFirebase, getUserById);
/**
 * @route PATCH /users/:id
 * @tags Admin
 * @summary Update users by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/users/:id", verifyFirebase, updateUserAdmin);
/**
 * @route PATCH /users/:id/role
 * @tags Admin
 * @summary Update users role by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/users/:id/role", verifyFirebase, verifyAdmin, updateUserRole);

/**
 * @route GET /check-role
 * @tags Admin
 * @summary Retrieve check role
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/check-role", verifyFirebase, (req, res) => {
  if (!req.user?.uid) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }
  User.findOne({ firebaseUID: req.user.id })
    .then((user) => {
      if (!user) return res.status(404).json({ message: "Not found" });
      return res.json({ role: user.role });
    })
    .catch((err) => res.status(500).json({ error: err.message }));
});

/**
 * @route GET /stats
 * @tags Admin
 * @summary Retrieve stats
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/stats", verifyFirebase, verifyAdmin, async (req, res) => {
  try {
    const total = await User.countDocuments();
    const admins = await User.countDocuments({ role: "admin" });
    const users = await User.countDocuments({ role: "user" });
    const active = await User.countDocuments({ isBlocked: false });
    const blocked = await User.countDocuments({ isBlocked: true });

    res.json({ total, admins, users, active, blocked });
  } catch (err) {
    res.status(500).json({ message: "Error loading stats", error: err });
  }
});
router.get(
  "/stats",
  verifyFirebase,
  verifyCapability("admin", "canViewStats"),
  getUserStats
);

router.patch(
  "/delivery/:id/status",
  requireRole(["driver"]),
  async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    const order = await Order.findOne({ "subOrders._id": id });
    if (!order) {
      res.status(404).json({ message: "الطلب غير موجود" });
      return;
    }

    const subOrder = order.subOrders.find((s) => s._id?.toString() === id);
    if (!subOrder) {
      res.status(404).json({ message: "الطلب الجزئي غير موجود" });
      return;
    }

    subOrder.deliveryStatus = status;
    await order.save();

    res.json({ message: "تم التحديث", status });
  }
);

export default router;