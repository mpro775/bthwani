import express from "express";
import { authenticate, authorize } from "../../middleware/auth.middleware";
import {
  listWithdrawals,
  approveWithdrawal,
  rejectWithdrawal,
} from "../../controllers/admin/admin.withdrawal.controller";

const router = express.Router();

router.get(
  "/",
  authenticate,
  authorize(["admin", "superadmin"]),
  listWithdrawals
);
router.patch(
  "/:id/approve",
  authenticate,
  authorize(["admin", "superadmin"]),
  approveWithdrawal
);
router.patch(
  "/:id/reject",
  authenticate,
  authorize(["admin", "superadmin"]),
  rejectWithdrawal
);

export default router;