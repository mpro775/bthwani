import express from "express";
import {
  createDriver,
  listDrivers,
  resetPassword,
  toggleBan,
  updateWallet,
  verifyDriver,
} from "../../controllers/admin/admin.driver.controller";
import { authenticate, authorize } from "../../middleware/auth.middleware";
import {
  confirmTransferToUser,
  initiateTransferToUser,
} from "../../controllers/driver_app/driver.controller";

const router = express.Router();

router.post(
  "/create",
  authenticate,
  authorize(["admin", "superadmin"]),
  createDriver
);
/**
 * @route GET /
 * @tags Admin
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", authenticate, authorize(["admin", "superadmin"]), listDrivers);
router.patch(
  "/:id/block",
  authenticate,
  authorize(["admin", "superadmin"]),
  toggleBan
);
router.patch(
  "/:id/verify",
  authenticate,
  authorize(["admin", "superadmin"]),
  verifyDriver
);
router.patch(
  "/:id/wallet",
  authenticate,
  authorize(["admin", "superadmin"]),
  updateWallet
);
router.patch(
  "/:id/reset-password",
  authenticate,
  authorize(["admin", "superadmin"]),
  resetPassword
);
/**
 * @route POST /wallet/initiate-transfer
 * @tags Admin
 * @summary Create wallet initiate transfer
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/wallet/initiate-transfer", authenticate, initiateTransferToUser);
/**
 * @route POST /wallet/confirm-transfer
 * @tags Admin
 * @summary Create wallet confirm transfer
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/wallet/confirm-transfer", authenticate, confirmTransferToUser);
export default router;