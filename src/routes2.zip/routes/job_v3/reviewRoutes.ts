import express from "express";
import {
  flagReview,
  getFreelancerReviews,
  submitReview,
} from "../../controllers/job_V3/reviewController";
import { verifyFirebase } from "../../middleware/verifyFirebase";

const router = express.Router();

/**
 * @route POST /:freelancerId
 * @tags JobV3
 * @summary Create by freelancerId
 * @param {freelancerId} freelancerId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/:freelancerId", verifyFirebase, submitReview);
/**
 * @route GET /:freelancerId
 * @tags JobV3
 * @summary Retrieve by freelancerId
 * @param {freelancerId} freelancerId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:freelancerId", getFreelancerReviews);
/**
 * @route PATCH /:id/flag
 * @tags JobV3
 * @summary Update flag by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id/flag", verifyFirebase, flagReview); // ✅ مسار الإبلاغ

export default router;