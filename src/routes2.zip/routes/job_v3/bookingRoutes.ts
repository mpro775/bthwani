import express from "express";
import {
  createBookingRequest,
  updateBookingStatus,
} from "../../controllers/job_V3/bookingController";
import { verifyFirebase } from "../../middleware/verifyFirebase";

const router = express.Router();

/**
 * @route POST /request
 * @tags JobV3
 * @summary Create request
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/request", verifyFirebase, createBookingRequest);
/**
 * @route PATCH /:id/status
 * @tags JobV3
 * @summary Update status by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id/status", verifyFirebase, updateBookingStatus);

export default router;