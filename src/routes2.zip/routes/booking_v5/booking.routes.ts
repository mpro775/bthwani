import express from "express";
import {
  getBookingById,
  updateBookingStatus,
} from "../../controllers/booking_V5/booking.controller";
import {
  getMyBookings,
  getServiceBookings,
} from "../../controllers/booking_V5/bookingService.controller";

const router = express.Router();

/**
 * @route GET /my
 * @tags BookingV5
 * @summary Retrieve my
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/my", getMyBookings); // حجوزات المستخدم
/**
 * @route GET /service/:id
 * @tags BookingV5
 * @summary Retrieve service by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/service/:id", getServiceBookings); // حجوزات لخدمة معينة
/**
 * @route PATCH /:id/status
 * @tags BookingV5
 * @summary Update status by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id/status", updateBookingStatus); // تحديث حالة حجز
/**
 * @route GET /:id
 * @tags BookingV5
 * @summary Retrieve by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id", getBookingById);

export default router;