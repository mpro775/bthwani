import express from "express";
import { verifyFirebase } from "../../middleware/verifyFirebase";
import {
  createMessage,
  getMessages,
} from "../../controllers/booking_V5/bookingMessage.controller";

const router = express.Router();

/**
 * @route POST /:bookingId/messages
 * @tags BookingV5
 * @summary Create messages by bookingId
 * @param {bookingId} bookingId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/:bookingId/messages", verifyFirebase, createMessage);
/**
 * @route GET /:bookingId/messages
 * @tags BookingV5
 * @summary Retrieve messages by bookingId
 * @param {bookingId} bookingId.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:bookingId/messages", verifyFirebase, getMessages);

export default router;