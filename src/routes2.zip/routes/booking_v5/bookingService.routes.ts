import express from "express";
import {
  createService,
  getAllServices,
  getServiceById,
  updateService,
  deleteService,
  getAvailability,
} from "../../controllers/booking_V5/bookingService.controller";

import {
  createBooking,
  updateBookingStatus,
} from "../../controllers/booking_V5/booking.controller";
import {
  submitReview,
  getServiceReviews,
} from "../../controllers/booking_V5/review.controller";
import { verifyFirebase } from "../../middleware/verifyFirebase";

const router = express.Router();

/**
 * @route POST /
 * @tags BookingV5
 * @summary Create
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/", verifyFirebase, createService); // إنشاء خدمة حجز
/**
 * @route GET /
 * @tags BookingV5
 * @summary Retrieve
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/", verifyFirebase, getAllServices); // جلب كل الخدمات مع الفلترة
/**
 * @route GET /:id
 * @tags BookingV5
 * @summary Retrieve by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id", verifyFirebase, getServiceById); // خدمة واحدة بالتفصيل
/**
 * @route PATCH /:id
 * @tags BookingV5
 * @summary Update by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.patch("/:id", verifyFirebase, updateService); // تعديل خدمة
/**
 * @route DELETE /:id
 * @tags BookingV5
 * @summary Delete by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.delete("/:id", verifyFirebase, deleteService); // حذف / تعطيل
/**
 * @route GET /:id/availability
 * @tags BookingV5
 * @summary Retrieve availability by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id/availability", verifyFirebase, getAvailability); // تقويم المواعيد
/**
 * @route POST /:id/book
 * @tags BookingV5
 * @summary Create book by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/:id/book", verifyFirebase, createBooking); // تقديم حجز
/**
 * @route POST /:id/review
 * @tags BookingV5
 * @summary Create review by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.post("/:id/review", verifyFirebase, submitReview); // تقييم بعد الإنجاز
/**
 * @route GET /:id/reviews
 * @tags BookingV5
 * @summary Retrieve reviews by id
 * @param {id} id.path.required - TODO: describe
 * @security bearerAuth
 * @return {object} 200 - TODO: success response
 */
router.get("/:id/reviews", getServiceReviews); // تقييمات مع المتوسط

export default router;